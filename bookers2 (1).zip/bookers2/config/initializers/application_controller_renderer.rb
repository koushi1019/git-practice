# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key = '52d62a85c792d41a7344830cefb3173aaa5967bc2b3f07ec12046c0a88757cc7e55183d0d5e24c037dab2da2773a5de3b3df77b2980bf18481a605970a701aba'